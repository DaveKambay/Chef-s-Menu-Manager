import React, { useState, useEffect, useMemo } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  StyleSheet,
  Alert,
  StatusBar,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';

import AsyncStorage from '@react-native-async-storage/async-storage';

import { MaterialCommunityIcons } from '@expo/vector-icons';


// ============================================================================
// 2. APPLICATION CONSTANTS
// ============================================================================

// All application colours are stored in one place.

const COLORS = {
  navy: '#0F2A5C',
  yellow: '#FDD14B',
  background: '#F5F7FB',
  white: '#FFFFFF',
  grey: '#6B7A99',
  border: '#E1E6F0',
  red: '#D64545',
  green: '#2E9E6A',
  lightBlue: '#EEF2FA',
  lightRed: '#FDECEC',
};

// Storage key used to save menu items on the device.

const STORAGE_KEY = 'CHEFS_MENU_MANAGER_ITEMS';

// Available menu courses.

const COURSES = [
  'Starter',
  'Main Course',
  'Dessert',
];

const FILTERS = [
  'All',
  ...COURSES,
];


// Course colours and icons.

const COURSE_LOOK = {
  Starter: {
    emoji: '🥗',
    background: '#DFF5E8',
    text: '#1F7A4D',
  },

  'Main Course': {
    emoji: '🍽️',
    background: '#FFF1C2',
    text: '#8A6500',
  },

  Dessert: {
    emoji: '🍰',
    background: '#FDE0EC',
    text: '#A8326B',
  },
};


// ============================================================================
// 3. STARTING MENU DATA
// ============================================================================

// The application starts with 30 example dishes.
// Once the user changes the menu, AsyncStorage saves those changes.

const STARTING_MENU = [

  // STARTERS

  {
    id: '1',
    name: 'Garlic Bread',
    description: 'Toasted bread with garlic butter and herbs.',
    course: 'Starter',
    price: 25,
  },

  {
    id: '2',
    name: 'Tomato Soup',
    description: 'Warm tomato soup served with a slice of bread.',
    course: 'Starter',
    price: 35,
  },

  {
    id: '3',
    name: 'Chicken Wings',
    description: 'Four grilled chicken wings with a mild sauce.',
    course: 'Starter',
    price: 45,
  },

  {
    id: '4',
    name: 'Greek Salad',
    description: 'Cucumber, tomato, lettuce, feta and olives.',
    course: 'Starter',
    price: 40,
  },

  {
    id: '5',
    name: 'Cheese Sticks',
    description: 'Crispy cheese sticks served with a dipping sauce.',
    course: 'Starter',
    price: 35,
  },

  {
    id: '6',
    name: 'Potato Wedges',
    description: 'Seasoned potato wedges served with a creamy dip.',
    course: 'Starter',
    price: 30,
  },

  {
    id: '7',
    name: 'Mini Beef Kebabs',
    description: 'Tender beef pieces grilled with peppers and onions.',
    course: 'Starter',
    price: 45,
  },

  {
    id: '8',
    name: 'Chicken Strips',
    description: 'Crispy chicken strips served with a small dip.',
    course: 'Starter',
    price: 40,
  },

  {
    id: '9',
    name: 'Stuffed Mushrooms',
    description: 'Mushrooms filled with herbed cheese and breadcrumbs.',
    course: 'Starter',
    price: 35,
  },

  {
    id: '10',
    name: 'Corn Fritters',
    description: 'Golden sweetcorn fritters served with a light sauce.',
    course: 'Starter',
    price: 30,
  },


  // MAIN COURSES

  {
    id: '11',
    name: 'Beef Burger',
    description: 'Beef patty with lettuce, tomato and house sauce, served with chips.',
    course: 'Main Course',
    price: 85,
  },

  {
    id: '12',
    name: 'Grilled Chicken and Rice',
    description: 'Grilled chicken served with rice and seasonal vegetables.',
    course: 'Main Course',
    price: 80,
  },

  {
    id: '13',
    name: 'Chicken Alfredo Pasta',
    description: 'Pasta in a creamy sauce with chicken pieces.',
    course: 'Main Course',
    price: 90,
  },

  {
    id: '14',
    name: 'Beef Stew',
    description: 'Slow-cooked beef stew served with pap or rice.',
    course: 'Main Course',
    price: 95,
  },

  {
    id: '15',
    name: 'Fish and Chips',
    description: 'Battered fish served with golden chips and lemon.',
    course: 'Main Course',
    price: 100,
  },

  {
    id: '16',
    name: 'Chicken Wrap',
    description: 'Grilled chicken, lettuce and tomato in a soft wrap.',
    course: 'Main Course',
    price: 70,
  },

  {
    id: '17',
    name: 'Vegetable Stir-fry',
    description: 'Fresh seasonal vegetables tossed in a light sauce with rice.',
    course: 'Main Course',
    price: 65,
  },

  {
    id: '18',
    name: 'Boerewors and Pap',
    description: 'Grilled boerewors served with pap and tomato relish.',
    course: 'Main Course',
    price: 75,
  },

  {
    id: '19',
    name: 'Chicken Schnitzel',
    description: 'Crumbed chicken breast served with chips and salad.',
    course: 'Main Course',
    price: 95,
  },

  {
    id: '20',
    name: 'Creamy Mushroom Pasta',
    description: 'Pasta with mushrooms in a creamy garlic sauce.',
    course: 'Main Course',
    price: 80,
  },


  // DESSERTS

  {
    id: '21',
    name: 'Chocolate Cake',
    description: 'A slice of chocolate cake with chocolate icing.',
    course: 'Dessert',
    price: 35,
  },

  {
    id: '22',
    name: 'Vanilla Ice Cream',
    description: 'Two scoops of vanilla ice cream.',
    course: 'Dessert',
    price: 25,
  },

  {
    id: '23',
    name: 'Malva Pudding',
    description: 'Traditional warm malva pudding with custard.',
    course: 'Dessert',
    price: 40,
  },

  {
    id: '24',
    name: 'Fruit Salad',
    description: 'A fresh mix of seasonal fruit.',
    course: 'Dessert',
    price: 30,
  },

  {
    id: '25',
    name: 'Chocolate Brownie',
    description: 'A soft chocolate brownie served as a single portion.',
    course: 'Dessert',
    price: 30,
  },

  {
    id: '26',
    name: 'Milk Tart',
    description: 'Traditional South African milk tart with cinnamon.',
    course: 'Dessert',
    price: 35,
  },

  {
    id: '27',
    name: 'Jelly and Custard',
    description: 'A classic serving of jelly with creamy custard.',
    course: 'Dessert',
    price: 25,
  },

  {
    id: '28',
    name: 'Banana Pancakes',
    description: 'Two small pancakes served with banana and syrup.',
    course: 'Dessert',
    price: 40,
  },

  {
    id: '29',
    name: 'Caramel Pudding',
    description: 'Smooth caramel-flavoured pudding served chilled.',
    course: 'Dessert',
    price: 35,
  },

  {
    id: '30',
    name: 'Lemon Cheesecake',
    description: 'A slice of creamy lemon cheesecake.',
    course: 'Dessert',
    price: 45,
  },

];


// ============================================================================
// 4. HELPER FUNCTIONS
// ============================================================================

// Convert a number into a South African Rand price.

function formatPrice(price) {
  return 'R' + Number(price).toFixed(2);
}


// Calculate course percentages.

function calculatePercentage(amount, total) {

  if (total === 0) {
    return 0;
  }

  return Math.round((amount / total) * 100);
}


// Validate information entered into the form.

function validateDish(
  name,
  description,
  course,
  priceText,
  menuItems,
  editingId
) {

  const errors = {};

  const cleanName = name.trim();
  const cleanDescription = description.trim();

  const normalisedPrice = priceText.trim().replace(',', '.');

  const price = Number(normalisedPrice);

  // Validate dish name.

  if (cleanName.length < 2) {

    errors.name = 'Dish name must contain at least 2 characters.';

  } else {

    const duplicate = menuItems.some(
      (dish) =>
        dish.id !== editingId &&
        dish.name.trim().toLowerCase() === cleanName.toLowerCase()
    );

    if (duplicate) {
      errors.name = 'This dish already exists.';
    }
  }


  // Validate description.

  if (cleanDescription.length < 5) {

    errors.description = 'Description must contain at least 5 characters.';

  }


  // Validate course.

  if (!COURSES.includes(course)) {

    errors.course = 'Please select a valid course.';

  }


  // Validate price.

  if (
    normalisedPrice === '' ||
    !/^\d+(\.\d{1,2})?$/.test(normalisedPrice) ||
    !Number.isFinite(price) ||
    price <= 0
  ) {

    errors.price = 'Enter a valid price greater than R0.';

  }


  return errors;
}


// ============================================================================
// 5. REUSABLE COMPONENT: STATISTIC TILE
// ============================================================================

// This component displays one statistic.
// We can reuse it for total dishes, average price and other information.

function StatisticTile({ title, value, icon }) {

  return (

    <View style={styles.statBox}>

      <MaterialCommunityIcons
        name={icon}
        size={22}
        color={COLORS.yellow}
      />

      <Text style={styles.statNumber}>
        {value}
      </Text>

      <Text style={styles.statLabel}>
        {title}
      </Text>

    </View>

  );
}


// ============================================================================
// 6. REUSABLE COMPONENT: STATISTICS DASHBOARD
// ============================================================================

function StatisticsDashboard({ statistics }) {

  const starterPercentage = calculatePercentage(
    statistics.starters,
    statistics.total
  );

  const mainPercentage = calculatePercentage(
    statistics.mains,
    statistics.total
  );

  const dessertPercentage = calculatePercentage(
    statistics.desserts,
    statistics.total
  );


  return (

    <View style={styles.statsCard}>

      <Text style={styles.sectionTitle}>
        Menu Statistics
      </Text>


      {/* Main statistics */}

      <View style={styles.statsRow}>

        <StatisticTile
          title="Total Dishes"
          value={statistics.total}
          icon="food"
        />

        <StatisticTile
          title="Average Price"
          value={formatPrice(statistics.average)}
          icon="calculator"
        />

      </View>


      {/* Price statistics */}

      <View style={styles.priceStatsRow}>

        <View style={styles.priceStatBox}>

          <Text style={styles.priceStatLabel}>
            Lowest Price
          </Text>

          <Text style={styles.priceStatValue}>
            {formatPrice(statistics.cheapest)}
          </Text>

        </View>


        <View style={styles.priceStatBox}>

          <Text style={styles.priceStatLabel}>
            Highest Price
          </Text>

          <Text style={styles.priceStatValue}>
            {formatPrice(statistics.mostExpensive)}
          </Text>

        </View>

      </View>


      {/* Course breakdown */}

      <Text style={styles.breakdownTitle}>
        Course Breakdown
      </Text>


      <CourseProgress
        title="Starters"
        amount={statistics.starters}
        percentage={starterPercentage}
        color="#2E9E6A"
      />


      <CourseProgress
        title="Main Courses"
        amount={statistics.mains}
        percentage={mainPercentage}
        color="#D6A42C"
      />


      <CourseProgress
        title="Desserts"
        amount={statistics.desserts}
        percentage={dessertPercentage}
        color="#C75B88"
      />

    </View>

  );

}


// ============================================================================
// 7. REUSABLE COMPONENT: COURSE PROGRESS
// ============================================================================

function CourseProgress({ title, amount, percentage, color }) {

  return (

    <View style={styles.progressContainer}>

      <View style={styles.progressHeading}>

        <Text style={styles.progressTitle}>
          {title} ({amount})
        </Text>

        <Text style={styles.progressPercentage}>
          {percentage}%
        </Text>

      </View>


      <View style={styles.progressBackground}>

        <View
          style={[
            styles.progressFill,
            {
              width: percentage + '%',
              backgroundColor: color,
            },
          ]}
        />

      </View>

    </View>

  );

}


// ============================================================================
// 8. REUSABLE COMPONENT: SEARCH BAR
// ============================================================================

function SearchBar({ value, onChangeText, onClear }) {

  return (

    <View style={styles.searchBox}>

      <MaterialCommunityIcons
        name="magnify"
        size={22}
        color={COLORS.grey}
      />


      <TextInput
        style={styles.searchInput}
        placeholder="Search dishes or descriptions..."
        placeholderTextColor={COLORS.grey}
        value={value}
        onChangeText={onChangeText}
        accessibilityLabel="Search menu items"
      />


      {value !== '' && (

        <TouchableOpacity
          onPress={onClear}
          accessibilityRole="button"
          accessibilityLabel="Clear search"
          style={styles.clearSearchButton}
        >

          <MaterialCommunityIcons
            name="close-circle"
            size={21}
            color={COLORS.grey}
          />

        </TouchableOpacity>

      )}

    </View>

  );

}


// ============================================================================
// 9. REUSABLE COMPONENT: COURSE FILTER
// ============================================================================

function CourseFilter({ selectedCourse, onSelect }) {

  return (

    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      style={styles.filterScroll}
      contentContainerStyle={styles.filterContent}
    >

      {FILTERS.map((filter) => (

        <TouchableOpacity
          key={filter}
          onPress={() => onSelect(filter)}
          style={[
            styles.filterButton,
            selectedCourse === filter && styles.filterButtonSelected,
          ]}
          accessibilityRole="button"
          accessibilityState={{
            selected: selectedCourse === filter,
          }}
        >

          <Text
            style={[
              styles.filterText,
              selectedCourse === filter && styles.filterTextSelected,
            ]}
          >
            {filter}
          </Text>

        </TouchableOpacity>

      ))}

    </ScrollView>

  );

}


// ============================================================================
// 10. REUSABLE COMPONENT: DISH CARD
// ============================================================================

// Each menu item is displayed using this reusable component.
// Edit and delete buttons are separate from the main card.
// This avoids nested TouchableOpacity interactions.

function DishCard({ item, onEdit, onDelete }) {

  const look = COURSE_LOOK[item.course] || COURSE_LOOK['Main Course'];


  return (

    <View style={styles.dishCard}>

      {/* Course emoji */}

      <View
        style={[
          styles.dishEmojiBox,
          { backgroundColor: look.background },
        ]}
      >

        <Text style={styles.dishEmoji}>
          {look.emoji}
        </Text>

      </View>


      {/* Dish information */}

      <View style={styles.dishDetails}>

        <Text style={styles.dishName}>
          {item.name}
        </Text>


        <Text
          style={[
            styles.courseBadge,
            {
              color: look.text,
              backgroundColor: look.background,
            },
          ]}
        >
          {item.course}
        </Text>


        <Text
          style={styles.dishDescription}
          numberOfLines={3}
        >
          {item.description}
        </Text>


        <Text style={styles.dishPrice}>
          {formatPrice(item.price)}
        </Text>

      </View>


      {/* Separate action buttons */}

      <View style={styles.dishActions}>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => onEdit(item)}
          accessibilityRole="button"
          accessibilityLabel={'Edit ' + item.name}
        >

          <MaterialCommunityIcons
            name="pencil"
            size={20}
            color={COLORS.navy}
          />

        </TouchableOpacity>


        <TouchableOpacity
          style={[styles.actionButton, styles.deleteButton]}
          onPress={() => onDelete(item)}
          accessibilityRole="button"
          accessibilityLabel={'Delete ' + item.name}
        >

          <MaterialCommunityIcons
            name="trash-can-outline"
            size={20}
            color={COLORS.red}
          />

        </TouchableOpacity>

      </View>

    </View>

  );

}


// ============================================================================
// 11. REUSABLE COMPONENT: EMPTY SEARCH RESULTS
// ============================================================================

function EmptyResults({ onClear }) {

  return (

    <View style={styles.emptyBox}>

      <MaterialCommunityIcons
        name="food-off"
        size={45}
        color={COLORS.grey}
      />


      <Text style={styles.emptyTitle}>
        No dishes found
      </Text>


      <Text style={styles.emptyText}>
        Try another search or choose a different course.
      </Text>


      <TouchableOpacity
        style={styles.clearFiltersButton}
        onPress={onClear}
      >

        <Text style={styles.clearFiltersText}>
          Clear Search and Filters
        </Text>

      </TouchableOpacity>

    </View>

  );

}


// ============================================================================
// 12. MAIN APPLICATION COMPONENT
// ============================================================================

export default function App() {


  // ========================================================================
  // A. APPLICATION STATE
  // ========================================================================

  // Stores all menu items.

  const [menuItems, setMenuItems] = useState(STARTING_MENU);


  // Controls which screen is displayed.

  const [screen, setScreen] = useState('home');


  // Stores the dish currently being edited.

  const [editingDish, setEditingDish] = useState(null);


  // Search and filtering state.

  const [searchText, setSearchText] = useState('');

  const [selectedCourse, setSelectedCourse] = useState('All');


  // Controls visibility of statistics.

  const [showStatistics, setShowStatistics] = useState(true);


  // Stores success messages.

  const [notice, setNotice] = useState('');


  // Stores form information.

  const [dishName, setDishName] = useState('');

  const [dishDescription, setDishDescription] = useState('');

  const [dishCourse, setDishCourse] = useState('Main Course');

  const [dishPrice, setDishPrice] = useState('');


  // Stores validation errors.

  const [formErrors, setFormErrors] = useState({});


  // Controls whether saved information has loaded.

  const [isLoaded, setIsLoaded] = useState(false);


  // ========================================================================
  // B. LOAD SAVED MENU ITEMS
  // ========================================================================

  // When the application opens, retrieve the saved menu.
  // If no saved menu exists, use the 30 starting dishes.

  useEffect(() => {

    async function loadMenu() {

      try {

        const savedMenu = await AsyncStorage.getItem(STORAGE_KEY);

        if (savedMenu !== null) {

          const parsedMenu = JSON.parse(savedMenu);

          if (Array.isArray(parsedMenu)) {
            setMenuItems(parsedMenu);
          }

        }

      } catch (error) {

        console.log('Error loading menu:', error);

        Alert.alert(
          'Loading Error',
          'The saved menu could not be loaded.'
        );

      } finally {

        setIsLoaded(true);

      }

    }

    loadMenu();

  }, []);


  // ========================================================================
  // C. SAVE MENU ITEMS
  // ========================================================================

  // Whenever the menu changes, save the new information.
  // The isLoaded check prevents the starting menu from overwriting
  // previously saved data before it has finished loading.

  useEffect(() => {

    async function saveMenu() {

      if (!isLoaded) {
        return;
      }

      try {

        await AsyncStorage.setItem(
          STORAGE_KEY,
          JSON.stringify(menuItems)
        );

      } catch (error) {

        console.log('Error saving menu:', error);

        Alert.alert(
          'Saving Error',
          'Your menu changes could not be saved.'
        );

      }

    }

    saveMenu();

  }, [menuItems, isLoaded]);


  // ========================================================================
  // D. SUCCESS MESSAGE
  // ========================================================================

  // Display a message and automatically remove it after 2.5 seconds.

  function showNotice(message) {

    setNotice(message);

  }


  useEffect(() => {

    if (notice === '') {
      return;
    }

    const timer = setTimeout(() => {

      setNotice('');

    }, 2500);


    // Clean up the timer when the message changes or screen unmounts.

    return () => clearTimeout(timer);

  }, [notice]);


  // ========================================================================
  // E. NAVIGATION FUNCTIONS
  // ========================================================================

  // Open a blank form to add a new dish.

  function openAddForm() {

    setEditingDish(null);

    setDishName('');

    setDishDescription('');

    setDishCourse('Main Course');

    setDishPrice('');

    setFormErrors({});

    setScreen('form');

  }


  // Open a form containing the existing dish information.

  function openEditForm(dish) {

    setEditingDish(dish);

    setDishName(dish.name);

    setDishDescription(dish.description);

    setDishCourse(dish.course);

    setDishPrice(String(dish.price));

    setFormErrors({});

    setScreen('form');

  }


  // Return to the home screen.

  function goHome() {

    setScreen('home');

    setEditingDish(null);

    setFormErrors({});

  }


  // ========================================================================
  // F. ADD AND UPDATE MENU ITEMS
  // ========================================================================

  function saveDish() {

    // Check that all information is valid.

    const errors = validateDish(
      dishName,
      dishDescription,
      dishCourse,
      dishPrice,
      menuItems,
      editingDish ? editingDish.id : null
    );


    // Display errors if information is incorrect.

    if (Object.keys(errors).length > 0) {

      setFormErrors(errors);

      return;

    }


    // Create a menu item using the information from the form.

    const dishToSave = {

      id: editingDish
        ? editingDish.id
        : Date.now().toString(),

      name: dishName.trim(),

      description: dishDescription.trim(),

      course: dishCourse,

      price: Number(dishPrice.trim().replace(',', '.')),

    };


    if (editingDish) {

      // UPDATE EXISTING MENU ITEM.

      setMenuItems((oldMenu) =>

        oldMenu.map((dish) =>

          dish.id === dishToSave.id
            ? dishToSave
            : dish

        )

      );

      showNotice('Menu item updated successfully.');

    } else {

      // ADD NEW MENU ITEM.

      setMenuItems((oldMenu) => [

        ...oldMenu,

        dishToSave,

      ]);

      showNotice('New menu item added successfully.');

    }


    // Return to the home screen after saving.

    goHome();

  }


  // ========================================================================
  // G. DELETE MENU ITEMS
  // ========================================================================

  function deleteDish(dish) {

    Alert.alert(

      'Delete Menu Item',

      'Are you sure you want to delete ' + dish.name + '?',

      [

        {
          text: 'Cancel',
          style: 'cancel',
        },


        {
          text: 'Delete',

          style: 'destructive',

          onPress: () => {

            // Remove the selected dish using its unique ID.

            setMenuItems((oldMenu) =>

              oldMenu.filter((item) => item.id !== dish.id)

            );

            showNotice('Menu item deleted successfully.');

          },

        },

      ]

    );

  }


  // ========================================================================
  // H. CLEAR SEARCH AND FILTERS
  // ========================================================================

  function clearFilters() {

    setSearchText('');

    setSelectedCourse('All');

  }


  // ========================================================================
  // I. SEARCH AND FILTER FUNCTIONALITY
  // ========================================================================

  // useMemo recalculates the results when the menu, search or filter changes.

  const visibleDishes = useMemo(() => {

    const search = searchText.trim().toLowerCase();

    return menuItems.filter((dish) => {

      const matchesSearch =

        dish.name.toLowerCase().includes(search) ||

        dish.description.toLowerCase().includes(search) ||

        dish.course.toLowerCase().includes(search);


      const matchesCourse =

        selectedCourse === 'All' ||

        dish.course === selectedCourse;


      return matchesSearch && matchesCourse;

    });

  }, [menuItems, searchText, selectedCourse]);


  // ========================================================================
  // J. MENU STATISTICS
  // ========================================================================

  // Calculate statistics from the complete menu.

  const statistics = useMemo(() => {

    const total = menuItems.length;


    // Calculate the combined price of all dishes.

    const totalPrice = menuItems.reduce(

      (sum, dish) => sum + Number(dish.price),

      0

    );


    // Calculate average price.

    const average = total === 0
      ? 0
      : totalPrice / total;


    // Get all menu prices.

    const prices = menuItems.map(

      (dish) => Number(dish.price)

    );


    return {

      total,

      average,

      cheapest: total === 0
        ? 0
        : Math.min(...prices),

      mostExpensive: total === 0
        ? 0
        : Math.max(...prices),


      // Count each course.

      starters: menuItems.filter(

        (dish) => dish.course === 'Starter'

      ).length,


      mains: menuItems.filter(

        (dish) => dish.course === 'Main Course'

      ).length,


      desserts: menuItems.filter(

        (dish) => dish.course === 'Dessert'

      ).length,

    };

  }, [menuItems]);


  // ========================================================================
  // K. LOADING SCREEN
  // ========================================================================

  if (!isLoaded) {

    return (

      <View style={styles.loadingScreen}>

        <MaterialCommunityIcons
          name="chef-hat"
          size={50}
          color={COLORS.navy}
        />

        <Text style={styles.loadingText}>
          Loading Menu Manager...
        </Text>

      </View>

    );

  }


  // ========================================================================
  // L. ADD / EDIT FORM SCREEN
  // ========================================================================

  if (screen === 'form') {

    return (

      <KeyboardAvoidingView
        style={styles.screen}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >

        <StatusBar barStyle="dark-content" />


        {/* Form header */}

        <View style={styles.header}>

          <TouchableOpacity
            onPress={goHome}
            style={styles.backButton}
            accessibilityRole="button"
            accessibilityLabel="Go back"
          >

            <MaterialCommunityIcons
              name="arrow-left"
              size={25}
              color={COLORS.navy}
            />

          </TouchableOpacity>


          <Text style={styles.headerTitle}>

            {editingDish
              ? 'Edit Menu Item'
              : 'Add Menu Item'}

          </Text>


          <View style={styles.backButton} />

        </View>


        <ScrollView
          contentContainerStyle={styles.formContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >


          <Text style={styles.formHeading}>
            {editingDish
              ? 'Update Dish Details'
              : 'Enter New Dish Details'}
          </Text>


          <Text style={styles.formSubtitle}>
            Complete all the fields below.
          </Text>


          {/* Dish name */}

          <Text style={styles.label}>
            Dish Name
          </Text>


          <TextInput
            style={[
              styles.input,
              formErrors.name && styles.inputError,
            ]}
            placeholder="Example: Chicken Burger"
            placeholderTextColor={COLORS.grey}
            value={dishName}
            onChangeText={(value) => {

              setDishName(value);

              if (formErrors.name) {
                setFormErrors((old) => ({
                  ...old,
                  name: undefined,
                }));
              }

            }}
            accessibilityLabel="Dish name"
          />


          {formErrors.name ? (

            <Text style={styles.errorText}>
              {formErrors.name}
            </Text>

          ) : null}


          {/* Dish description */}

          <Text style={styles.label}>
            Description
          </Text>


          <TextInput
            style={[
              styles.input,
              styles.descriptionInput,
              formErrors.description && styles.inputError,
            ]}
            placeholder="Describe the ingredients and dish..."
            placeholderTextColor={COLORS.grey}
            value={dishDescription}
            onChangeText={(value) => {

              setDishDescription(value);

              if (formErrors.description) {
                setFormErrors((old) => ({
                  ...old,
                  description: undefined,
                }));
              }

            }}
            multiline
            textAlignVertical="top"
            accessibilityLabel="Dish description"
          />


          {formErrors.description ? (

            <Text style={styles.errorText}>
              {formErrors.description}
            </Text>

          ) : null}


          {/* Course selection */}

          <Text style={styles.label}>
            Select Course
          </Text>


          <View style={styles.courseChoices}>

            {COURSES.map((course) => (

              <TouchableOpacity
                key={course}
                onPress={() => {

                  setDishCourse(course);

                  setFormErrors((old) => ({
                    ...old,
                    course: undefined,
                  }));

                }}
                style={[
                  styles.courseChoice,
                  dishCourse === course &&
                    styles.courseChoiceSelected,
                ]}
                accessibilityRole="button"
                accessibilityState={{
                  selected: dishCourse === course,
                }}
              >

                <Text
                  style={[
                    styles.courseChoiceText,
                    dishCourse === course &&
                      styles.courseChoiceTextSelected,
                  ]}
                >
                  {course}
                </Text>

              </TouchableOpacity>

            ))}

          </View>


          {formErrors.course ? (

            <Text style={styles.errorText}>
              {formErrors.course}
            </Text>

          ) : null}


          {/* Price */}

          <Text style={styles.label}>
            Price (South African Rand)
          </Text>


          <TextInput
            style={[
              styles.input,
              formErrors.price && styles.inputError,
            ]}
            placeholder="Example: 75.00"
            placeholderTextColor={COLORS.grey}
            value={dishPrice}
            onChangeText={(value) => {

              setDishPrice(value);

              if (formErrors.price) {
                setFormErrors((old) => ({
                  ...old,
                  price: undefined,
                }));
              }

            }}
            keyboardType="decimal-pad"
            accessibilityLabel="Dish price"
          />


          {formErrors.price ? (

            <Text style={styles.errorText}>
              {formErrors.price}
            </Text>

          ) : null}


          {/* Save button */}

          <TouchableOpacity
            style={styles.primaryButton}
            onPress={saveDish}
            accessibilityRole="button"
          >

            <MaterialCommunityIcons
              name="content-save"
              size={20}
              color={COLORS.white}
            />


            <Text style={styles.primaryButtonText}>

              {editingDish
                ? 'Update Menu Item'
                : 'Save Menu Item'}

            </Text>

          </TouchableOpacity>


          {/* Cancel button */}

          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={goHome}
          >

            <Text style={styles.secondaryButtonText}>
              Cancel
            </Text>

          </TouchableOpacity>


        </ScrollView>

      </KeyboardAvoidingView>

    );

  }


  // ========================================================================
  // M. HOME SCREEN
  // ========================================================================

  return (

    <View style={styles.screen}>

      <StatusBar barStyle="dark-content" />


      {/* Application header */}

      <View style={styles.header}>

        <View style={styles.headerIcon}>

          <MaterialCommunityIcons
            name="chef-hat"
            size={28}
            color={COLORS.navy}
          />

        </View>


        <Text style={styles.headerTitle}>
          Menu Manager
        </Text>


        <View style={styles.headerIcon} />

      </View>


      <View style={styles.homeContent}>


        {/* Page title and statistics toggle */}

        <View style={styles.titleRow}>

          <View>

            <Text style={styles.pageTitle}>
              Restaurant Menu
            </Text>

            <Text style={styles.subtitle}>
              View and manage all menu items
            </Text>

          </View>


          <TouchableOpacity
            style={styles.statsToggle}
            onPress={() => setShowStatistics((old) => !old)}
            accessibilityRole="button"
            accessibilityLabel="Toggle menu statistics"
          >

            <MaterialCommunityIcons
              name="chart-box-outline"
              size={19}
              color={COLORS.navy}
            />


            <Text style={styles.statsToggleText}>
              {showStatistics ? 'Hide' : 'Stats'}
            </Text>

          </TouchableOpacity>

        </View>


        {/* Statistics dashboard */}

        {showStatistics && (

          <StatisticsDashboard
            statistics={statistics}
          />

        )}


        {/* Search bar */}

        <SearchBar
          value={searchText}
          onChangeText={setSearchText}
          onClear={() => setSearchText('')}
        />


        {/* Course filters */}

        <CourseFilter
          selectedCourse={selectedCourse}
          onSelect={setSelectedCourse}
        />


        {/* Menu list heading */}

        <View style={styles.resultsRow}>

          <Text style={styles.sectionTitle}>
            Menu Items
          </Text>


          <Text style={styles.resultCount}>
            {visibleDishes.length} of {menuItems.length} dishes
          </Text>

        </View>


        {/* Display menu items */}

        <FlatList
          data={visibleDishes}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={styles.listContent}


          // Display this component when the menu has no matching results.

          ListEmptyComponent={

            <EmptyResults
              onClear={clearFilters}
            />

          }


          // Render every dish using the reusable DishCard component.

          renderItem={({ item }) => (

            <DishCard
              item={item}
              onEdit={openEditForm}
              onDelete={deleteDish}
            />

          )}

        />

      </View>


      {/* Bottom add menu item button */}

      <View style={styles.footer}>

        <TouchableOpacity
          style={styles.primaryButton}
          onPress={openAddForm}
          accessibilityRole="button"
          accessibilityLabel="Add a new menu item"
        >

          <MaterialCommunityIcons
            name="plus"
            size={23}
            color={COLORS.white}
          />


          <Text style={styles.primaryButtonText}>
            Add Menu Item
          </Text>

        </TouchableOpacity>

      </View>


      {/* Success notification */}

      {notice !== '' && (

        <View
          style={styles.notice}
          accessibilityLiveRegion="polite"
        >

          <MaterialCommunityIcons
            name="check-circle"
            size={21}
            color={COLORS.white}
          />


          <Text style={styles.noticeText}>
            {notice}
          </Text>

        </View>

      )}

    </View>

  );

}


// ============================================================================
// 13. APPLICATION STYLES
// ============================================================================

// All visual styles are organised in one StyleSheet.

const styles = StyleSheet.create({


  // GENERAL SCREEN

  screen: {
    flex: 1,
    backgroundColor: COLORS.background,
  },


  loadingScreen: {
    flex: 1,
    backgroundColor: COLORS.background,
    alignItems: 'center',
    justifyContent: 'center',
  },


  loadingText: {
    marginTop: 15,
    fontSize: 15,
    color: COLORS.navy,
    fontWeight: '700',
  },


  // HEADER

  header: {
    backgroundColor: COLORS.yellow,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'android'
      ? (StatusBar.currentHeight || 24) + 8
      : 54,
    paddingBottom: 14,
  },


  headerIcon: {
    width: 38,
    alignItems: 'center',
  },


  backButton: {
    width: 38,
    alignItems: 'center',
    justifyContent: 'center',
  },


  headerTitle: {
    fontSize: 21,
    fontWeight: '800',
    color: COLORS.navy,
  },


  // HOME SCREEN

  homeContent: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 15,
  },


  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },


  pageTitle: {
    fontSize: 23,
    fontWeight: '800',
    color: COLORS.navy,
  },


  subtitle: {
    fontSize: 12,
    color: COLORS.grey,
    marginTop: 3,
  },


  statsToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: '#E8EDF8',
    padding: 10,
    borderRadius: 12,
  },


  statsToggleText: {
    color: COLORS.navy,
    fontWeight: '700',
    fontSize: 12,
  },


  // STATISTICS DASHBOARD

  statsCard: {
    backgroundColor: COLORS.white,
    padding: 13,
    borderRadius: 16,
    marginBottom: 12,
    elevation: 2,
  },


  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.navy,
  },


  statsRow: {
    flexDirection: 'row',
    gap: 9,
    marginTop: 10,
  },


  statBox: {
    flex: 1,
    backgroundColor: COLORS.navy,
    borderRadius: 12,
    padding: 9,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 75,
  },


  statNumber: {
    color: COLORS.yellow,
    fontSize: 18,
    fontWeight: '800',
    marginTop: 3,
  },


  statLabel: {
    color: COLORS.white,
    fontSize: 10,
    marginTop: 3,
    textAlign: 'center',
  },


  priceStatsRow: {
    flexDirection: 'row',
    gap: 9,
    marginTop: 9,
  },


  priceStatBox: {
    flex: 1,
    backgroundColor: COLORS.lightBlue,
    borderRadius: 10,
    padding: 9,
    alignItems: 'center',
  },


  priceStatLabel: {
    color: COLORS.grey,
    fontSize: 11,
  },


  priceStatValue: {
    color: COLORS.navy,
    fontSize: 15,
    fontWeight: '800',
    marginTop: 3,
  },


  breakdownTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: COLORS.navy,
    marginTop: 12,
    marginBottom: 5,
  },


  progressContainer: {
    marginTop: 6,
  },


  progressHeading: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },


  progressTitle: {
    color: COLORS.grey,
    fontSize: 10,
    fontWeight: '700',
  },


  progressPercentage: {
    color: COLORS.navy,
    fontSize: 10,
    fontWeight: '800',
  },


  progressBackground: {
    height: 6,
    backgroundColor: COLORS.border,
    borderRadius: 5,
    overflow: 'hidden',
  },


  progressFill: {
    height: 6,
    borderRadius: 5,
  },


  // SEARCH BAR

  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 13,
    paddingHorizontal: 12,
    marginBottom: 10,
  },


  searchInput: {
    flex: 1,
    height: 44,
    marginLeft: 8,
    color: COLORS.navy,
    fontSize: 13,
  },


  clearSearchButton: {
    padding: 3,
  },


  // FILTER BUTTONS

  filterScroll: {
    maxHeight: 43,
    marginBottom: 10,
  },


  filterContent: {
    alignItems: 'center',
  },


  filterButton: {
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 9,
    marginRight: 7,
  },


  filterButtonSelected: {
    backgroundColor: COLORS.navy,
    borderColor: COLORS.navy,
  },


  filterText: {
    color: COLORS.grey,
    fontSize: 12,
    fontWeight: '700',
  },


  filterTextSelected: {
    color: COLORS.white,
  },


  // MENU LIST

  resultsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 9,
  },


  resultCount: {
    color: COLORS.grey,
    fontSize: 11,
  },


  listContent: {
    paddingBottom: 12,
    flexGrow: 1,
  },


  dishCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderRadius: 15,
    padding: 11,
    marginBottom: 10,
    elevation: 2,
  },


  dishEmojiBox: {
    width: 48,
    height: 48,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
  },


  dishEmoji: {
    fontSize: 24,
  },


  dishDetails: {
    flex: 1,
    marginHorizontal: 9,
  },


  dishName: {
    color: COLORS.navy,
    fontSize: 14,
    fontWeight: '800',
  },


  courseBadge: {
    alignSelf: 'flex-start',
    overflow: 'hidden',
    borderRadius: 8,
    paddingHorizontal: 7,
    paddingVertical: 3,
    fontSize: 10,
    fontWeight: '700',
    marginTop: 4,
    marginBottom: 4,
  },


  dishDescription: {
    color: COLORS.grey,
    fontSize: 11,
    lineHeight: 15,
  },


  dishPrice: {
    color: COLORS.navy,
    fontSize: 14,
    fontWeight: '800',
    marginTop: 5,
  },


  dishActions: {
    gap: 7,
  },


  actionButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: COLORS.lightBlue,
    alignItems: 'center',
    justifyContent: 'center',
  },


  deleteButton: {
    backgroundColor: COLORS.lightRed,
  },


  // EMPTY SEARCH RESULTS

  emptyBox: {
    alignItems: 'center',
    paddingVertical: 35,
    paddingHorizontal: 15,
  },


  emptyTitle: {
    color: COLORS.navy,
    fontSize: 17,
    fontWeight: '800',
    marginTop: 10,
  },


  emptyText: {
    color: COLORS.grey,
    textAlign: 'center',
    marginTop: 5,
    fontSize: 12,
  },


  clearFiltersButton: {
    marginTop: 14,
    padding: 10,
  },


  clearFiltersText: {
    color: COLORS.navy,
    fontWeight: '800',
    fontSize: 13,
  },


  // FOOTER

  footer: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: Platform.OS === 'android' ? 12 : 18,
    backgroundColor: COLORS.background,
  },


  // PRIMARY BUTTON

  primaryButton: {
    backgroundColor: COLORS.navy,
    borderRadius: 13,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },


  primaryButtonText: {
    color: COLORS.white,
    fontWeight: '800',
    fontSize: 15,
  },


  // FORM SCREEN

  formContent: {
    padding: 18,
    paddingBottom: 40,
  },


  formHeading: {
    color: COLORS.navy,
    fontSize: 21,
    fontWeight: '800',
    marginTop: 5,
  },


  formSubtitle: {
    color: COLORS.grey,
    fontSize: 13,
    marginTop: 5,
  },


  label: {
    color: COLORS.navy,
    fontSize: 14,
    fontWeight: '800',
    marginTop: 18,
    marginBottom: 7,
  },


  input: {
    backgroundColor: COLORS.white,
    borderWidth: 1.3,
    borderColor: COLORS.border,
    borderRadius: 12,
    paddingHorizontal: 13,
    paddingVertical: 13,
    color: COLORS.navy,
    fontSize: 14,
  },


  descriptionInput: {
    minHeight: 100,
  },


  inputError: {
    borderColor: COLORS.red,
  },


  errorText: {
    color: COLORS.red,
    fontSize: 11,
    marginTop: 5,
  },


  // COURSE CHOICES

  courseChoices: {
    flexDirection: 'row',
    gap: 7,
  },


  courseChoice: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 4,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: COLORS.white,
    alignItems: 'center',
  },


  courseChoiceSelected: {
    backgroundColor: COLORS.yellow,
    borderColor: COLORS.yellow,
  },


  courseChoiceText: {
    color: COLORS.grey,
    fontSize: 10,
    fontWeight: '700',
    textAlign: 'center',
  },


  courseChoiceTextSelected: {
    color: COLORS.navy,
  },


  // SECONDARY BUTTON

  secondaryButton: {
    borderWidth: 1.5,
    borderColor: COLORS.navy,
    backgroundColor: COLORS.white,
    borderRadius: 13,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 10,
  },


  secondaryButtonText: {
    color: COLORS.navy,
    fontWeight: '800',
    fontSize: 15,
  },


  // SUCCESS NOTIFICATION

  notice: {
    position: 'absolute',
    top: 100,
    left: 18,
    right: 18,
    backgroundColor: COLORS.green,
    padding: 13,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    elevation: 5,
  },


  noticeText: {
    color: COLORS.white,
    fontWeight: '700',
    fontSize: 12,
    flex: 1,
  },


});

