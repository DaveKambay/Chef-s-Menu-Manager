import React, { useState } from 'react';

// React Native components
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Image,
  Alert,
} from 'react-native';


// ----------------------------------------------------
// SAMPLE MENU ITEMS
// These help us see how the menu will look.
// ----------------------------------------------------

const startingMenu = [
  {
    id: '1',
    name: 'Burger',
    description: 'Beef patty, lettuce, tomato, onion and Barbeque sauce.',
    course: 'Main Course',
    price: '60',
    image:
      'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300',
  },

  {
    id: '2',
    name: 'Chicken and rice bowl',
    description: 'Grilled chicken and rice with fresh vegetables.',
    course: 'Main Course',
    price: '80',
    image:
      'https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?w=300',
  },

  {
    id: '3',
    name: 'Chocolate cake',
    description: 'Rich chocolate cake with chocolate cream.',
    course: 'Dessert',
    price: '30',
    image:
      'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=300',
  },
];


// ----------------------------------------------------
// MAIN APP
// ----------------------------------------------------

export default function App() {

  // This controls which screen we see.
  // "home" = menu screen
  // "add" = add menu item screen
  const [screen, setScreen] = useState('home');


  // Stores all menu items
  const [menuItems, setMenuItems] = useState(startingMenu);


  // Stores information typed into the form
  const [dishName, setDishName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState('');
  const [price, setPrice] = useState('');


  // --------------------------------------------------
  // ADD MENU ITEM FUNCTION
  // --------------------------------------------------

  const addMenuItem = () => {

    // Check if the user left anything empty
    if (
      dishName.trim() === '' ||
      description.trim() === '' ||
      course === '' ||
      price.trim() === ''
    ) {

      Alert.alert(
        'Missing Information',
        'Please complete all the fields before saving.'
      );

      return;
    }


    // Check that price contains numbers
    if (isNaN(price)) {

      Alert.alert(
        'Invalid Price',
        'Please enter a valid price.'
      );

      return;
    }


    // Create a new menu item
    const newItem = {
      id: Date.now().toString(),
      name: dishName,
      description: description,
      course: course,
      price: price,
      image:
        'https://images.unsplash.com/photo-1547592180-85f173990554?w=300',
    };


    // Add the new item to the menu
    setMenuItems([...menuItems, newItem]);


    // Clear the form
    setDishName('');
    setDescription('');
    setCourse('');
    setPrice('');


    // Show success message
    Alert.alert(
      'Success!',
      'The menu item has been added successfully.'
    );


    // Return to the home screen
    setScreen('home');
  };


  // --------------------------------------------------
  // MENU ITEM CARD
  // --------------------------------------------------

  const MenuItem = ({ item }) => {

    return (
      <View style={styles.menuCard}>

        {/* Food image */}
        <Image
          source={{ uri: item.image }}
          style={styles.foodImage}
        />


        {/* Information about the food */}
        <View style={styles.foodInformation}>

          {/* Dish name */}
          <Text style={styles.foodName}>
            {item.name}
          </Text>


          {/* Course badge */}
          <View style={styles.courseBadge}>
            <Text style={styles.courseBadgeText}>
              {item.course}
            </Text>
          </View>


          {/* Description */}
          <Text
            style={styles.foodDescription}
            numberOfLines={2}
          >
            {item.description}
          </Text>


          {/* Price */}
          <Text style={styles.foodPrice}>
            R{item.price}
          </Text>

        </View>


        {/* Arrow on the right */}
        <Text style={styles.arrow}>
          ›
        </Text>

      </View>
    );
  };


  // --------------------------------------------------
  // HOME SCREEN
  // --------------------------------------------------

  if (screen === 'home') {

    return (

      <SafeAreaView style={styles.container}>

        {/* HEADER */}
        <View style={styles.header}>

          {/* Menu icon */}
          <Text style={styles.headerIcon}>
            ☰
          </Text>


          {/* App title */}
          <Text style={styles.headerTitle}>
            Menu Manager
          </Text>


          {/* Chef icon */}
          <Text style={styles.chefIcon}>
            👨‍🍳
          </Text>

        </View>


        {/* HOME CONTENT */}
        <View style={styles.homeContent}>

          {/* Main heading */}
          <Text style={styles.pageTitle}>
            Restaurant Menu
          </Text>


          {/* Subtitle */}
          <Text style={styles.subtitle}>
            View and manage all menu items
          </Text>


          {/* SEARCH BAR */}
          <View style={styles.searchContainer}>

            <Text style={styles.searchIcon}>
              🔍
            </Text>

            <TextInput
              style={styles.searchInput}
              placeholder="Search menu items..."
              placeholderTextColor="#7B8798"
            />

            <Text style={styles.filterIcon}>
              ☰
            </Text>

          </View>


          {/* MENU LIST */}
          {menuItems.length > 0 ? (

            <FlatList
              data={menuItems}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <MenuItem item={item} />
              )}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.listContent}
            />

          ) : (

            // Empty state
            <View style={styles.emptyContainer}>

              <Text style={styles.emptyIcon}>
                🍽️
              </Text>

              <Text style={styles.emptyTitle}>
                No menu items yet
              </Text>

              <Text style={styles.emptyText}>
                Add your first menu item to get started.
              </Text>

            </View>
          )}


          {/* TOTAL ITEMS */}
          <Text style={styles.totalItems}>
            Total Items: {menuItems.length}
          </Text>


          {/* ADD BUTTON */}
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => setScreen('add')}
          >

            <Text style={styles.plus}>
              +
            </Text>

            <Text style={styles.addButtonText}>
              Add Menu Item
            </Text>

          </TouchableOpacity>

        </View>

      </SafeAreaView>
    );
  }


  // --------------------------------------------------
  // ADD MENU ITEM SCREEN
  // --------------------------------------------------

  return (

    <SafeAreaView style={styles.container}>

      {/* HEADER */}
      <View style={styles.header}>

        {/* Back button */}
        <TouchableOpacity
          onPress={() => setScreen('home')}
        >

          <Text style={styles.backArrow}>
            ‹
          </Text>

        </TouchableOpacity>


        {/* Page title */}
        <Text style={styles.headerTitle}>
          Add Menu Item
        </Text>


        {/* Empty space to keep title centred */}
        <View style={{ width: 35 }} />

      </View>


      {/* FORM */}
      <View style={styles.formContainer}>

        {/* DISH NAME */}
        <Text style={styles.label}>
          Dish Name
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Enter the dish name"
          placeholderTextColor="#8793A5"
          value={dishName}
          onChangeText={setDishName}
        />


        {/* DESCRIPTION */}
        <Text style={styles.label}>
          Description
        </Text>

        <TextInput
          style={[styles.input, styles.descriptionInput]}
          placeholder="Enter description of the dish"
          placeholderTextColor="#8793A5"
          multiline={true}
          value={description}
          onChangeText={setDescription}
        />


        {/* COURSE */}
        <Text style={styles.label}>
          Course
        </Text>


        {/* COURSE BUTTONS */}
        <View style={styles.courseContainer}>

          {/* Starter */}
          <TouchableOpacity
            style={[
              styles.courseButton,
              course === 'Starter' && styles.selectedCourse,
            ]}
            onPress={() => setCourse('Starter')}
          >

            <Text
              style={[
                styles.courseText,
                course === 'Starter' && styles.selectedCourseText,
              ]}
            >
              Starter
            </Text>

          </TouchableOpacity>


          {/* Main Course */}
          <TouchableOpacity
            style={[
              styles.courseButton,
              course === 'Main Course' && styles.selectedCourse,
            ]}
            onPress={() => setCourse('Main Course')}
          >

            <Text
              style={[
                styles.courseText,
                course === 'Main Course' &&
                  styles.selectedCourseText,
              ]}
            >
              Main Course
            </Text>

          </TouchableOpacity>


          {/* Dessert */}
          <TouchableOpacity
            style={[
              styles.courseButton,
              course === 'Dessert' && styles.selectedCourse,
            ]}
            onPress={() => setCourse('Dessert')}
          >

            <Text
              style={[
                styles.courseText,
                course === 'Dessert' && styles.selectedCourseText,
              ]}
            >
              Dessert
            </Text>

          </TouchableOpacity>

        </View>


        {/* PRICE */}
        <Text style={styles.label}>
          Price
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Enter price"
          placeholderTextColor="#8793A5"
          keyboardType="numeric"
          value={price}
          onChangeText={setPrice}
        />


        {/* SAVE BUTTON */}
        <TouchableOpacity
          style={styles.saveButton}
          onPress={addMenuItem}
        >

          <Text style={styles.saveButtonText}>
            ✓   Save Menu Item
          </Text>

        </TouchableOpacity>


        {/* CANCEL BUTTON */}
        <TouchableOpacity
          style={styles.cancelButton}
          onPress={() => setScreen('home')}
        >

          <Text style={styles.cancelButtonText}>
            Cancel
          </Text>

        </TouchableOpacity>

      </View>

    </SafeAreaView>
  );
}


// ====================================================
// STYLES
// ====================================================

const styles = StyleSheet.create({

  // Main app background
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },


  // --------------------------------------------------
  // HEADER
  // --------------------------------------------------

  header: {
    height: 82,
    backgroundColor: '#FFD447',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 22,
  },

  headerIcon: {
    fontSize: 27,
    color: '#173B70',
  },

  chefIcon: {
    fontSize: 28,
  },

  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#173B70',
  },

  backArrow: {
    fontSize: 40,
    color: '#173B70',
    lineHeight: 40,
  },


  // --------------------------------------------------
  // HOME SCREEN
  // --------------------------------------------------

  homeContent: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 25,
  },

  pageTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#173B70',
    marginBottom: 5,
  },

  subtitle: {
    fontSize: 16,
    color: '#718096',
    marginBottom: 22,
  },


  // --------------------------------------------------
  // SEARCH
  // --------------------------------------------------

  searchContainer: {
    height: 50,
    backgroundColor: '#FFFFFF',
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#D4DCE6',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
    marginBottom: 18,
  },

  searchIcon: {
    fontSize: 19,
    marginRight: 8,
  },

  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#173B70',
  },

  filterIcon: {
    fontSize: 20,
    color: '#173B70',
  },


  // --------------------------------------------------
  // MENU CARDS
  // --------------------------------------------------

  listContent: {
    paddingBottom: 10,
  },

  menuCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    minHeight: 135,
    marginBottom: 14,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',

    // Small border instead of using another colour
    borderWidth: 1,
    borderColor: '#E1E7EF',
  },

  foodImage: {
    width: 95,
    height: 95,
    borderRadius: 48,
  },

  foodInformation: {
    flex: 1,
    marginLeft: 14,
  },

  foodName: {
    fontSize: 17,
    fontWeight: '700',
    color: '#173B70',
    marginBottom: 5,
  },

  courseBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#FFF0B5',
    borderRadius: 15,
    paddingHorizontal: 10,
    paddingVertical: 3,
    marginBottom: 5,
  },

  courseBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#173B70',
  },

  foodDescription: {
    fontSize: 13,
    color: '#68758A',
    lineHeight: 18,
    marginBottom: 5,
  },

  foodPrice: {
    fontSize: 17,
    fontWeight: '700',
    color: '#173B70',
  },

  arrow: {
    fontSize: 35,
    color: '#173B70',
    marginLeft: 5,
  },


  // --------------------------------------------------
  // EMPTY STATE
  // --------------------------------------------------

  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
  },

  emptyIcon: {
    fontSize: 45,
    marginBottom: 12,
  },

  emptyTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#173B70',
    marginBottom: 5,
  },

  emptyText: {
    fontSize: 14,
    color: '#718096',
    textAlign: 'center',
  },


  // --------------------------------------------------
  // TOTAL ITEMS
  // --------------------------------------------------

  totalItems: {
    textAlign: 'center',
    fontSize: 14,
    fontWeight: '600',
    color: '#718096',
    marginVertical: 10,
  },


  // --------------------------------------------------
  // ADD BUTTON
  // --------------------------------------------------

  addButton: {
    height: 55,
    backgroundColor: '#173B70',
    borderRadius: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
  },

  plus: {
    fontSize: 28,
    color: '#FFFFFF',
    marginRight: 8,
    marginTop: -2,
  },

  addButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '700',
  },


  // --------------------------------------------------
  // ADD FORM
  // --------------------------------------------------

  formContainer: {
    flex: 1,
    paddingHorizontal: 25,
    paddingTop: 25,
  },

  label: {
    fontSize: 18,
    fontWeight: '600',
    color: '#173B70',
    marginBottom: 8,
    marginTop: 10,
  },

  input: {
    height: 55,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#CDD6E2',
    borderRadius: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    color: '#173B70',
    marginBottom: 10,
  },

  descriptionInput: {
    height: 120,
    paddingTop: 15,
    textAlignVertical: 'top',
  },


  // --------------------------------------------------
  // COURSE BUTTONS
  // --------------------------------------------------

  courseContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },

  courseButton: {
    flex: 1,
    height: 50,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#CDD6E2',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 3,
  },

  selectedCourse: {
    backgroundColor: '#FFD447',
    borderColor: '#FFD447',
  },

  courseText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#173B70',
  },

  selectedCourseText: {
    fontWeight: '700',
  },


  // --------------------------------------------------
  // SAVE BUTTON
  // --------------------------------------------------

  saveButton: {
    height: 58,
    backgroundColor: '#173B70',
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15,
  },

  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '700',
  },


  // --------------------------------------------------
  // CANCEL BUTTON
  // --------------------------------------------------

  cancelButton: {
    height: 58,
    backgroundColor: '#FFFFFF',
    borderWidth: 2,
    borderColor: '#173B70',
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
  },

  cancelButtonText: {
    color: '#173B70',
    fontSize: 17,
    fontWeight: '700',
  },

});